package com.senai.cadastroaluno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroalunoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroalunoApplication.class, args);
	}

}
