package com.senai.cadastroaluno.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.senai.cadastroaluno.entities.Aluno;

@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Long>{
	
	//Consulta p/ encontrar por rm
	Aluno findByRm(String rm);
	
	//Consulta p/ encontrar por email
	Aluno findByEmail(String email);
}
