package com.senai.cadastroaluno.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.senai.cadastroaluno.entities.Aluno;
import com.senai.cadastroaluno.services.AlunoService;

@RestController
@RequestMapping("/alunos")
public class AlunoController {

	@Autowired
	private AlunoService alunoService;

	// Listar todos os usuários
	@GetMapping
	public List<Aluno> getAll() {
		return alunoService.findAll();
	}

	// Buscar usuário por ID
	@GetMapping("/{id}")
	public Aluno getById(@PathVariable Long id) {
		return alunoService.findById(id);
	}

	// Criar novo usuário
	@PostMapping
	public Aluno create(@RequestBody Aluno aluno) {
		return alunoService.save(aluno);
	}

	// Deletar usuário por ID
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Long id) {
		alunoService.delete(id);
	}
	
	//Busca por RM
	@GetMapping("/buscarporrm")
	public Aluno getByRm(@RequestParam String rm) {
		return alunoService.findByRm(rm);
	}
	
	@PostMapping("/login")
	public Aluno login(@RequestBody Aluno loginRequest) {
		
		Aluno pessoa = alunoService.autenticarAluno(loginRequest.getEmail(), loginRequest.getSenha());
		
		if(pessoa != null) {
			return pessoa;
		}
		else {
			return null;
		}
	}
}
