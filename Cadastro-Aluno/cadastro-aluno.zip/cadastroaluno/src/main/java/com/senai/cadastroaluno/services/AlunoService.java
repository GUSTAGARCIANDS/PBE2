package com.senai.cadastroaluno.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senai.cadastroaluno.entities.Aluno;
import com.senai.cadastroaluno.repositories.AlunoRepository;

@Service
public class AlunoService {

	@Autowired
	private AlunoRepository alunoRepository;

	public List<Aluno> findAll() {
		return alunoRepository.findAll();
	}

	public Aluno findById(Long id) {
		return alunoRepository.findById(id).get();
	}

	public Aluno save(Aluno aluno) {
		return alunoRepository.save(aluno);
	}

	public void delete(Long id) {
		alunoRepository.deleteById(id);
	}
	
	public Aluno findByRm(String rm) {
		return alunoRepository.findByRm(rm);
	}
	
	public Aluno autenticarAluno(String email, String senha) {
		Aluno pessoa = alunoRepository.findByEmail(email);
		
		if(pessoa != null && pessoa.getSenha().equals(senha)) {
			return pessoa;
		}
		else {
			return null;
		}
	}
}
