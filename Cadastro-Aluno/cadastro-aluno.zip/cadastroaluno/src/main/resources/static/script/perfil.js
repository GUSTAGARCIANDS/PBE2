document.addEventListener('DOMContentLoaded', () => {
	
  const alunoJson = localStorage.getItem('alunoLogado');

  if (!alunoJson) {
    alert('Aluno não está logado! Redirecionando para o login...');
    window.location.href = 'login.html'; 
    return;
  }

  const aluno = JSON.parse(alunoJson);
  document.getElementById('nome').textContent = aluno.nome || '';
  document.getElementById('idade').textContent = aluno.idade || '';
  document.getElementById('email').textContent = aluno.email || '';
  document.getElementById('rm').textContent = aluno.rm || '';

  document.getElementById('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem('alunoLogado');
    alert('Logout efetuado!');
    window.location.href = 'login.html';
  });
});