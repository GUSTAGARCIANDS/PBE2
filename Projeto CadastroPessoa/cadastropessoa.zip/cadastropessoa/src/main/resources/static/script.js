// Quando clicar no botão "Cadastrar"
document.getElementById('formCadastro').addEventListener('submit', function(e) {
	e.preventDefault();

	const nomeConst = document.getElementById('nomeFormulario').value;
	const idadeConst = document.getElementById('idadeFormulario').value;

	// Enviar para a API
	fetch('http://localhost:8080/cadastropessoa', {
		method: 'POST',
		headers: { 'Content-Type': 'application/json' },
		body: JSON.stringify(
			{ 
				nomePessoaAtributo: nomeConst, 
				idadePessoaAtributo: idadeConst 
			})
	});

	document.getElementById('formCadastro').reset();
	location.reload();

});

// Quando a página carregar
window.onload = function() {
	// Buscar pessoinhas da API e mostrar na tabela
	fetch('http://localhost:8080/cadastropessoa')
		.then(res => res.json())
		.then(pessoinhas => {
			const tabela = document.getElementById('tabelaPessoas').querySelector('tbody');
			pessoinhas.forEach(p => {
				const linha = tabela.insertRow();
				linha.insertCell(0).textContent = p.nomePessoaAtributo;
				linha.insertCell(1).textContent = p.idadePessoaAtributo;
			});
		});
};