package com.senai.cadastropessoa.entities.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.senai.cadastropessoa.entities.CadastroPessoa;

@Repository
public interface CadastroPessoaRepository extends JpaRepository<CadastroPessoa, Long>{
	
}
