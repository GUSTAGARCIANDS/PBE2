package com.senai.cadastropessoa.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_cadastro_pessoa")
public class CadastroPessoa {
	//Atributos
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idPessoa;
	
	@Column(name = "nomePessoa", nullable = false)
	private String nomePessoa;
	
	@Column(name = "idadePessoa", nullable = false)
	private int idadePessoa;
	
	//Construtores
	CadastroPessoa() {
		
	}
	
	CadastroPessoa(Long idPessoa, String nomePessoa, int idadePessoa) {
		this.idPessoa = idPessoa;
		this.nomePessoa = nomePessoa;
		this.idadePessoa = idadePessoa;
	}

	//Getters e Setters
	public Long getId() {
		return idPessoa;
	}

	public void setId(Long idPessoa) {
		this.idPessoa = idPessoa;
	}

	public String getNomePessoa() {
		return nomePessoa;
	}

	public void setNomePessoa(String nomePessoa) {
		this.nomePessoa = nomePessoa;
	}

	public int getIdadePessoa() {
		return idadePessoa;
	}

	public void setIdadePessoa(int idadePessoa) {
		this.idadePessoa = idadePessoa;
	}
}
